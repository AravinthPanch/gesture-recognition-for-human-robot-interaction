package de.dailabor.ml.knn.similarmeasure;

import de.dailabor.ml.mlutilitylibrary.dataset.TimeSeries;
import de.dailabor.ml.mlutilitylibrary.util.Parameter;

abstract public class SimilarityMeasure {

    protected Parameter parameter;

    public SimilarityMeasure(final Parameter parameter) {
        this.parameter = parameter;
    }

    abstract public double measureSimilarity(TimeSeries Q, TimeSeries C);

    abstract public double measureSimilarity(TimeSeries Q, TimeSeries C, double cutOff);

    public void setParameter(final Parameter parameter) {
        this.parameter = parameter;
    }

    public Parameter getParameter() {
        return this.parameter;
    }

}
