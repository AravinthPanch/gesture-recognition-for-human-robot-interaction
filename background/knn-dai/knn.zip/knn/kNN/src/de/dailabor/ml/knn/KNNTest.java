package de.dailabor.ml.knn;

import java.util.HashMap;

import de.dailabor.ml.mlutilitylibrary.dataset.Instance;
import de.dailabor.ml.mlutilitylibrary.dataset.TimeSeries;
import de.dailabor.ml.mlutilitylibrary.dataset.TrainingSet;
import de.dailabor.ml.mlutilitylibrary.util.IOUtils;
import de.dailabor.ml.mlutilitylibrary.util.Parameter;
import de.dailabor.ml.mlutilitylibrary.util.ResultList;
import de.dailabor.ml.mlutilitylibrary.util.math.TimeSeriesOps;
import de.dailabor.ml.similaritymeasures.LTW;

public class KNNTest {

    /**
     * @param args
     */
    public static void main(final String[] args) {

        // laod training examples:
        // td.put(instance_name_1,
        // Array_with_file_names_containing_training_data_for_this_instance_name_1);
        // td.put(instance_name_2,
        // Array_with_file_names_containing_training_data_for_this_instance_name_2);
        String prefix = "data\\Train\\";
        final String ext = ".dat";
        final HashMap<String, String[]> td = new HashMap<String, String[]>();
        td.put("TurnLeft", new String[]{prefix + "TurnLeft_0" + ext,
                prefix + "TurnLeft_1" + ext, prefix + "TurnLeft_2" + ext,
                prefix + "TurnLeft_3" + ext});
        td.put("TurnRight", new String[]{prefix + "TurnRight_0" + ext,
                prefix + "TurnRight_1" + ext, prefix + "TurnRight_2" + ext,
                prefix + "TurnRight_3" + ext});
        td.put("CircleLeft", new String[]{prefix + "CircleLeft_0" + ext,
                prefix + "CircleLeft_1" + ext, prefix + "CircleLeft_2" + ext,
                prefix + "CircleLeft_3" + ext});
        td.put("CircleRight", new String[]{prefix + "CircleRight_0" + ext,
                prefix + "CircleRight_1" + ext, prefix + "CircleRight_2" + ext,
                prefix + "CircleRight_3" + ext});
        td.put("Arrow", new String[]{prefix + "Arrow_0" + ext});
        td.put("Shake", new String[]{prefix + "Shake_0" + ext, prefix + "Shake_1" + ext,
                prefix + "Shake_2" + ext});

        final TrainingSet ts = new TrainingSet();
        for(final String in : td.keySet()) {
            final String[] fnl = td.get(in);
            for(final String fn : fnl) {
                final Instance i = new Instance(in, 6);
                i.setTimeSeries(TimeSeriesOps.zscore(IOUtils.loadDataFromFile(fn, new int[]{
                        1, 1, 1, 1, 1, 1})));
                ts.addInstance(i);
            }
        }

        final Parameter param = new Parameter("Param.xml");
        final KNN knn = new KNN(new LTW(param), param);

        knn.setTrainingSet(ts);
        prefix = "data\\Test\\";

        final long start = System.currentTimeMillis();
        // here we load the test instances from file
        for(final String g : td.keySet()) {
            for(int n = 0; n < 3; n++) {

                final TimeSeries C = TimeSeriesOps.zscore(IOUtils.loadDataFromFile(prefix + g + "_" + n + ext, new int[]{
                        1, 1, 1, 1, 1, 1}));

                final ResultList res = knn.classify(C);

                System.out.println("############################\nTest: " + g + " " + n);
                System.out.println(res.toString());

            } // for each test example

        }
        System.out.println("Time: " + (System.currentTimeMillis() - start));

    }
}
