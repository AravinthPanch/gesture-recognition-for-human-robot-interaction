package de.dailabor.ml.knn.similarmeasure;

import de.dailabor.ml.mlutilitylibrary.dataset.TimeSeries;
import de.dailabor.ml.mlutilitylibrary.util.Parameter;

public class DTW extends SimilarityMeasure {

    private final de.dailabor.ml.similaritymeasures.DTW dtw;

    public DTW(final Parameter parameter) {
        super(parameter);
        this.dtw = new de.dailabor.ml.similaritymeasures.DTW(parameter);
    }

    @Override
    public double measureSimilarity(final TimeSeries Q, final TimeSeries C) {
        return measureSimilarity(Q, C, Double.POSITIVE_INFINITY);
    }

    @Override
    public double measureSimilarity(final TimeSeries Q, final TimeSeries C, final double cutOff) {
        return this.dtw.measureSimilarity(Q, C, cutOff);
    }

}
