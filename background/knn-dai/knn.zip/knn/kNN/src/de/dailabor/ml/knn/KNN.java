package de.dailabor.ml.knn;

import de.dailabor.ml.mlutilitylibrary.dataset.Instance;
import de.dailabor.ml.mlutilitylibrary.dataset.TimeSeries;
import de.dailabor.ml.mlutilitylibrary.dataset.TrainingSet;
import de.dailabor.ml.mlutilitylibrary.util.Parameter;
import de.dailabor.ml.mlutilitylibrary.util.ResultList;
import de.dailabor.ml.similaritymeasures.SimilarityMeasure;

public class KNN {

    private SimilarityMeasure sm;

    private TrainingSet trainingSet;

    private final Parameter parameter;

    public KNN(final Parameter parameter) {
        this.sm = null;
        this.parameter = parameter;
    }

    public KNN(final SimilarityMeasure similarMeasurment, final Parameter parameter) {
        this.sm = similarMeasurment;
        this.parameter = parameter;
    }

    public void setSimilarityMeasure(final SimilarityMeasure sm) {
        this.sm = sm;
    }

    public SimilarityMeasure getSimilarityMeasure() {
        return this.sm;
    }

    public void setTrainingSet(final TrainingSet ts) {
        this.trainingSet = ts;
    }

    public ResultList classify(final TimeSeries C) {

        final ResultList rl = new ResultList(true);

        double d = 0.0;
        double dmin = Double.POSITIVE_INFINITY;

        for(final Instance i : this.trainingSet.getInstances()) {
            d = this.sm.measureSimilarity(i.getTimeSeries(), C, dmin);
            if(d < dmin) {
                dmin = d;
            }
            rl.addResult(i.getId(), d);
        }

        return rl;
    }
}
